// Serial CLI test orchestration. All semantic decisions come from native Julia.
import fs from 'node:fs';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
const dir='/tmp/hsm-recovery-julia-sol-raw-controls';
const cases=JSON.parse(fs.readFileSync(dir+'/cases.json','utf8')).cases;
const reasons={
 'wrong-physical-print-binding':'physical witness print',
 'floating-integer-claim':'JSON integer token required',
 'wrong-full-pose-count':'independently enumerated graph node count',
 'illegal-recovery-word':'explicit legal single-space-separated move notation',
 'float-version-token':'unsupported recovery input version',
 'whole-valued-float-edge-limit':'JSON integer token required',
 'exponent-integer-claim':'JSON integer token required'
};
fs.mkdirSync(dir+'/runs',{recursive:true});
const records=[];
for(const c of cases) {
 const out=dir+'/runs/'+c.name;
 const args=['/tmp/hsm-recovery-julia-sol-smoke/capture.py',out,'/tmp/julia-1.13.3/bin/julia','--startup-file=no'];
 if(c.name!=='wrong-full-pose-count')args.push('--compile=min');
 args.push('--project=proof-checkers/julia','proof-checkers/julia/recovery.jl',c.path,'/tmp/hsm-modes-source.json');
 const child=spawnSync('python3',args,{stdio:'inherit',env:{...process.env,JULIA_DEPOT_PATH:'/tmp/cubistry-julia-depot'}});
 const result=JSON.parse(fs.readFileSync(out+'/stdout.jsonl','utf8'));
 const actualHash=crypto.createHash('sha256').update(fs.readFileSync(c.path)).digest('hex');
 const reasonOK=!reasons[c.name] || result.reason.includes(reasons[c.name]);
 const passed=child.status===c.expectedExit && result.valid===false && result.status===c.expectedStatus && actualHash===c.sha256 && reasonOK;
 const record={name:c.name,inputSHA256:actualHash,expectedExit:c.expectedExit,actualExit:child.status,expectedStatus:c.expectedStatus,nativeResult:result,reasonMatchesExpectedDefect:reasonOK,passed};
 records.push(record);fs.writeFileSync(dir+'/results.json',JSON.stringify({status:passed?'RUNNING':'FAIL_UNKNOWN',cases:records},null,2)+'\n');
 console.log(JSON.stringify(record));
 if(!passed)process.exit(1);
}
fs.writeFileSync(dir+'/results.json',JSON.stringify({status:'PASS_NATIVE_RAW_CONTROLS',cases:records},null,2)+'\n');
console.log('PASS_NATIVE_RAW_CONTROLS '+records.length);
