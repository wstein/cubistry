# Data hashes and names only: never evaluates a proof or expected verdict.
import hashlib,json,pathlib,re
root=pathlib.Path.cwd(); manifest=root/'proof-checkers/conformance-hsm/manifest.json'
raw=manifest.read_bytes(); digest=hashlib.sha256(raw).hexdigest()
source=(root/'proof-checkers/julia/Hsm.jl').read_text()
pin=re.search(r'const HSM_MANIFEST_PIN = "([0-9a-f]{64})"',source).group(1)
assert digest==pin
assert digest in (root/'proof-checkers/flix/src/Hsm.flix').read_text()
data=json.loads(raw); cases=data['cases']; assert len(cases)==data['caseCount']==46
assert len({c['name'] for c in cases})==46
assert {p.name for p in (root/'proof-checkers/conformance-hsm/cases').iterdir()}=={c['name']+'.json' for c in cases}
for c in cases:
 assert c['path']=='proof-checkers/conformance-hsm/cases/'+c['name']+'.json'
 assert hashlib.sha256((root/c['path']).read_bytes()).hexdigest()==c['sha256']
print(json.dumps({'status':'PASS_DATA_PINS','cases':46,'manifestSHA256':digest,'nativeVerdictsExecuted':False}))
