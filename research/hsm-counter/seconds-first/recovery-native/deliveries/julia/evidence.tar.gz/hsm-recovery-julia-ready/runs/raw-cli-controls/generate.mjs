// Data fixture construction only; native Julia decides every actual result.
import fs from 'node:fs';
import crypto from 'node:crypto';
const dir='/tmp/hsm-recovery-julia-sol-raw-controls';
const raw=fs.readFileSync('/tmp/hsm-recovery-source.json','utf8');
const cases=[];
function add(name,bytes,expectedStatus='INVALID') {
 const path=dir+'/'+name+'.json';fs.writeFileSync(path,bytes);
 cases.push({name,path,expectedValid:false,expectedStatus,expectedExit:expectedStatus==='UNSUPPORTED'?2:1,sha256:crypto.createHash('sha256').update(bytes).digest('hex')});
}
for(const [name,change] of [
 ['wrong-physical-print-binding',d=>d.printCode='broken '+d.printCode],
 ['floating-integer-claim',d=>d.modes[0].graphNodes=303264.5],
 ['wrong-full-pose-count',d=>d.modes[0].graphNodes++],
 ['illegal-recovery-word',d=>d.modes[0].samples[0].words[0]='x']]) {
 const d=JSON.parse(raw);change(d);add(name,JSON.stringify(d)+'\n');
}
add('duplicate-key',raw.replace('"label":','"label":"duplicate", "label":'),'INVALID_JSON');
add('float-version-token',raw.replace('"version": 1,','"version": 1.0,'),'UNSUPPORTED');
add('whole-valued-float-edge-limit',raw.replace('"edgeLimitHTM": 5,','"edgeLimitHTM": 5.0,'));
add('exponent-integer-claim',raw.replace('"graphNodes": 303264,','"graphNodes": 303264e0,'));
fs.writeFileSync(dir+'/cases.json',JSON.stringify({purpose:'Fixture construction only; expected defects are tested by the native raw CLI, not by this generator',cases},null,2)+'\n');
console.log('Constructed eight raw mutation fixtures; no proof verdict computed.');
