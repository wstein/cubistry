# Julia recovery evidence package

Local delivery package for the coordinator. Do not publish until the complete
proof/PR step. Do not provide the complete Julia output to the independent Flix
author before their own native full acceptance.

Overall status: UNKNOWN pending independent Flix and final review. Julia source
249df9d31b1d2c6daa617e88f898ff0c25906300 accepted all 18 rows. The mathematical
source is frozen; later commits change documentation only.

- runs/complete-positive: exact 9756-byte native valid JSON line, stderr,
  measured process capture, complete loaded-source snapshot and runtime/driver
  provenance. Output SHA-256:
  0d0d139589dfe9a39524967ebe543c4316c9343e0e0d4c05966b5a5ef3283c70.
- runs/parser-controls: 23/23 focused exact-decimal assertions.
- runs/semantic-controls: 78/78 native assertions, including unpruned physical
  replay, independently rebuilt graph mutations and nonoptimal legal detour.
- runs/raw-cli-controls: all eight actual native CLI mutation cases, expected
  and observed statuses/exits, defect-specific reasons and individual resources.
- regressions: native 195-case conformance VALID, old hsm recovery UNSUPPORTED
  with expected exit 2, and separate 195/46 data-pin audits. The complete old 46
  native HSM semantic suite was not rerun.
- inputs: exact frozen raw files from research revision
  30b6d022da60c366d79de5498497df0a07e28caf.
- source: current frozen native sources, drivers, tests and Project/Manifest.
- docs: contract/wire format, implementation instructions, documented mean-token
  root cause, independent static review and full Julia execution report.
- history: first partial UNKNOWN smoke and deliberately interrupted obsolete
  baseline. Neither is a complete proof. The obsolete run includes the actual
  source loaded before SIGINT; its structured context says INTERRUPTED_UNKNOWN.

Actual commands and environment selectors are in each capture/context. Relative
portable commands are in docs/RECOVERY-README.md; the committed old corpus files
are byte-identical to inputs/recovery.json and inputs/modes.json. Reproduction
requires the repository at the recorded source and its unchanged corpus.

Python files here only instrument subprocess/resources or audit data hashes.
They do not verify proofs or settle dissent. Julia is the native source of the
recorded outcomes. No Flix result or cross-language confirmation is asserted.

manifest.json hashes every payload file. manifest.sha256 and the separately
reported archive digest authenticate the package index and archive respectively.
